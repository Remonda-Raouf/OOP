package com.mycompany.project;
public class Circle extends Shape {
      private double radius;
      
      // Setters & getters 
      public void setradius(double radius)
      {
   	   this.radius = radius;
      }
      public double getradius()
      {
   	   return radius;
      }
       
      //
      @Override
      public double getArea()
      {
    	  return Math.PI * this.radius * this.radius;
      }
      @Override
      public double getPerimeter()
      {
    	  return Math.PI * this.radius * 2;
      }
      @Override
      public String HowToDraw()
      {
    	  return "Circle";
      }
      
      //constructor
      public Circle (double radius)
      {
    	  super();
    	  this.radius = radius;
      }
      public Circle (double radius , String color)
      {
    	  super(color);
    	  this.radius = radius;
      }
     
     //to string
      @Override
      public String toString() {
        return "Circle{" + "radius=" + radius + '}';
      }
      
      
}

