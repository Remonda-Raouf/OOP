package com.mycompany.project;
public interface Drawable {
    
	 // abstract
      public abstract String HowToDraw();
}
