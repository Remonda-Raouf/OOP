package com.mycompany.project;
public abstract class ThreeShape extends Shape{
	
      public abstract double getvolume();
      
      // constructor 
      public ThreeShape()
      {
    	  
      }
      public ThreeShape (String color)
      {
    	  super(color);
      }
}