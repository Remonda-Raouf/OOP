package com.mycompany.project;
public class Project {
    public static void main(String[] args) {
       
        Frame frame = new Frame();
        frame.setSize(300, 200); 
        frame.setVisible(true);  
        frame.setDefaultCloseOperation(Frame.EXIT_ON_CLOSE);

        new Frame().show();
       int n = Integer.parseInt(args [0]);
	Drawable [] ar = new Drawable[n];
	double sum  = 0 ;
	for ( int  i = 0 ; i < n ; i++){
	    String type = args[i * 2 + 1];
	    double l = Double.parseDouble(args[i * 2 + 2]);
	    switch(type.toLowerCase()){
		    case "circle" :
		          ar[i] = new Circle(l);
			  sum += ((Circle) ar[i]).getArea();
			       break; 
		    case "cube" :
			    ar[i] = new Cube(l);
		            sum += ((Cube) ar[i]).getArea();
			       break;
                    default :
                        System.out.println("Unknown shape type: " + type);
                        return;
			} 
		} 
        System.out.print(sum);
    }
}
