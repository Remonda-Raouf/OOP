package com.mycompany.project;
import java.util.Date;
public abstract class Shape implements Drawable{
    private Date datacreated;
	private String color;
	 
	// setters & getters
	public Date getdatacreated()
	{
		return datacreated;
	}
	public String getcolor()
	 {
		 return color;
	 }
	 public void setdatacreated(Date datacreated)
	 {
		 this.datacreated = datacreated;
	 }
	 public void setcolor (String color )
	 {
		 this.color = color;
	 }
	 
	// constructor 
	public Shape () {
		
	}
	
     public Shape (String color ) {
		this.color = color;
	}
     
     // abstract
     public abstract double getArea();
     public abstract double getPerimeter();
} 

