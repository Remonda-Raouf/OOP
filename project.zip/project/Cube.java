package com.mycompany.project;
public class Cube extends ThreeShape{
       private double side;
       
       // Setters & getters 
       public void setside(double side)
       {
    	   this.side = side;
       }
       public double getside()
       {
    	   return side;
       }
       
       //
	@Override
	public String HowToDraw() {
		return "cube";
	}
	@Override
	public double getvolume() {
		return Math.pow(this.side, 3);
	}
	@Override
	public double getArea() {
		return 6 * this.side * this.side;
	}
	@Override
	public double getPerimeter() {
		return this.side * this.side;
	}
       
    // constructor
	public Cube (String color , double side)
	{
		super(color);
		this.side = side;
	}
	public Cube (double side)
	{
		this.side = side;
	}
	
	//to string
        @Override
	public String toString()
	{
		return "Cube {" + "side =" + side + '}';
	}
}
